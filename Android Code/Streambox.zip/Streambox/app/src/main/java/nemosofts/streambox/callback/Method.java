package nemosofts.streambox.callback;

public class Method {

    public static final String METHOD_APP_DETAILS = "app_details";
    public static final String METHOD_GET_DEVICE_ID = "get_device_user";
    public static final String METHOD_REPORT = "post_report";
    public static final String METHOD_POSTER = "get_poster";
}
