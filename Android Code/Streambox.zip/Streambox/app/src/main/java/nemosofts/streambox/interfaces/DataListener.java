package nemosofts.streambox.interfaces;

public interface DataListener {
    void onStart();
    void onEnd(String success);
}