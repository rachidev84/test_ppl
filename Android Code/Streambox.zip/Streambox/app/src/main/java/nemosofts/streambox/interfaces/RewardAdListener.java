package nemosofts.streambox.interfaces;

public interface RewardAdListener {
    void isPlaying(boolean playWhenReady);
}
